package com.secrethq.ads;
import org.cocos2dx.lib.Cocos2dxActivity;

public class PTAdFacebookBridge {
	public static void initBridge(Cocos2dxActivity activity){
	}

	public static void initBanner(){
	}

	public static void initInterstitial(){
	}

	public static void showFullScreen(){
	}

	public static void showBannerAd(){
	}

	public static void hideBannerAd(){
	}

	public static boolean isBannerVisisble() {
		return false;
	}

}
